extends CanvasLayer
const Style=preload("res://ui/style.gd")
const Report=preload("res://scripts/performance_report.gd")
var monitor:Node
var shell:PanelContainer
var summary:RichTextLabel
var counters:RichTextLabel
var ranking:Tree
var slow_frames:Tree
var slow_cpu:Tree
var status:Label
var indicator:Label
var _previous_mouse:=Input.MOUSE_MODE_VISIBLE
var _elapsed:=0.0

func _ready()->void:
	layer=220
	process_mode=Node.PROCESS_MODE_ALWAYS
	shell=PanelContainer.new()
	shell.name="PerformancePanel"
	shell.theme=Style.make_theme()
	shell.add_theme_stylebox_override("panel",Style.make_glass_panel_style(-1,0.96))
	shell.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shell.offset_left=16
	shell.offset_top=16
	shell.offset_right=-16
	shell.offset_bottom=-16
	shell.add_to_group("fullscreen_workbench")
	add_child(shell)
	var margin:=MarginContainer.new()
	for side in ["left","right","top","bottom"]: margin.add_theme_constant_override("margin_"+side,16)
	shell.add_child(margin)
	var body:=VBoxContainer.new()
	body.add_theme_constant_override("separation",10)
	margin.add_child(body)
	var header:=HBoxContainer.new()
	body.add_child(header)
	var title:=_label("性能检测 · F10",&"title")
	title.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	header.add_child(title)
	header.add_child(_button("关闭面板继续游戏",close_panel))
	var help:=_label("先开始采样，再关闭面板正常游玩；到时自动停止。打开面板不会暂停世界。",&"caption")
	help.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	body.add_child(help)
	var actions:=HFlowContainer.new()
	body.add_child(actions)
	actions.add_child(_label("统计窗口"))
	var window:=OptionButton.new()
	for value in [60,120,240,600,1800]: window.add_item("最近 %d 帧"%value,value)
	window.select(2)
	window.item_selected.connect(func(index:int):monitor.window_frames=window.get_item_id(index);refresh())
	actions.add_child(window)
	actions.add_child(_label("录制时长"))
	var duration:=OptionButton.new()
	for value in [15,30,60,120,0]: duration.add_item("%d 秒"%value if value>0 else "手动停止",value)
	duration.select(1)
	duration.item_selected.connect(func(index:int):monitor.duration_seconds=duration.get_item_id(index))
	actions.add_child(duration)
	actions.add_child(_button("开始采样（重置）",func():monitor.start();refresh()))
	actions.add_child(_button("停止",func():monitor.stop();refresh()))
	actions.add_child(_button("重置",func():monitor.reset();refresh()))
	actions.add_child(_button("刷新",refresh))
	actions.add_child(_button("复制报告",_copy_report))
	actions.add_child(_button("导出 JSON + 报告",_export))
	actions.add_child(_button("打开导出目录",_open_directory))
	var note:=LineEdit.new()
	note.placeholder_text="备注：例如中心河岸、奔跑转镜头、雨天、出现卡顿的位置"
	note.text_changed.connect(func(value:String):monitor.note=value)
	body.add_child(note)
	status=_label("尚未开始采样",&"caption")
	status.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	body.add_child(status)
	var tabs:=TabContainer.new()
	tabs.size_flags_vertical=Control.SIZE_EXPAND_FILL
	body.add_child(tabs)
	summary=_text_tab(tabs,"概览与诊断")
	ranking=_tree_tab(tabs,"CPU 分项",["分项","平均 ms","P50 ms","P95 ms","P99 ms","峰值 ms","累计 ms","分项占比","墙钟占比","活跃帧"])
	slow_frames=_tree_tab(tabs,"慢帧样本",["帧序","间隔 ms","脚本 ms","GPU ms","位置","主要分项"])
	slow_cpu=_tree_tab(tabs,"脚本慢帧",["帧序","间隔 ms","脚本 ms","GPU ms","位置","主要分项"])
	counters=_text_tab(tabs,"环境与计数器")
	indicator=_label("",&"caption")
	indicator.theme=Style.make_theme()
	indicator.mouse_filter=Control.MOUSE_FILTER_IGNORE
	indicator.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	indicator.offset_left=-260
	indicator.offset_right=-16
	indicator.offset_top=70
	indicator.offset_bottom=110
	add_child(indicator)
	shell.hide()

func _label(text:String,role:StringName=&"body")->Label:
	var item:=Label.new()
	item.text=text
	Style.apply_text_role(item,role)
	return item
func _button(text:String,callback:Callable)->Button:
	var item:=Button.new()
	item.text=text
	Style.style_button(item)
	item.pressed.connect(callback)
	return item
func _text_tab(tabs:TabContainer,title:String)->RichTextLabel:
	var text:=RichTextLabel.new()
	text.name=title
	text.bbcode_enabled=false
	text.selection_enabled=true
	text.add_theme_font_override("normal_font",Style.make_font())
	text.add_theme_font_size_override("normal_font_size",14)
	tabs.add_child(text)
	return text
func _tree_tab(tabs:TabContainer,title:String,headers:Array)->Tree:
	var tree:=Tree.new()
	tree.name=title
	tree.columns=headers.size()
	tree.hide_root=true
	tree.column_titles_visible=true
	for i in headers.size():
		tree.set_column_title(i,headers[i])
		tree.set_column_custom_minimum_width(i,90 if i>0 else 150)
	tree.set_column_expand_ratio(0,2)
	tabs.add_child(tree)
	return tree

func is_open()->bool:return is_instance_valid(shell) and shell.visible
func open_panel()->void:
	_previous_mouse=Input.mouse_mode
	Input.mouse_mode=Input.MOUSE_MODE_VISIBLE
	shell.show()
	refresh()
func close_panel()->void:
	if not is_open(): return
	shell.hide()
	Input.mouse_mode=_previous_mouse
func _input(event:InputEvent)->void:
	if is_open() and event is InputEventKey and event.pressed and event.keycode==KEY_ESCAPE:
		close_panel()
		get_viewport().set_input_as_handled()
func _process(delta:float)->void:
	_elapsed+=delta
	if _elapsed<0.5:return
	_elapsed=0
	indicator.visible=monitor.recording and not is_open()
	indicator.text="性能采样中 · %d 帧 · F10"%monitor.total_frames
	if is_open(): refresh()

func refresh()->void:
	var model:Dictionary=monitor.snapshot()
	status.text=("录制中" if monitor.recording else "已停止")+" · 累计 %d 帧 · 窗口 %d 帧 · 慢帧阈值 %.2f ms · 目标 %.0f FPS"%[monitor.total_frames,model.sample_frames,monitor.threshold_ms,monitor.target_fps]
	var lines:Array[String]=["平均 %.1f FPS · 实际采样 %.2f 秒"%[model.average_fps,model.duration_ms/1000.0],""]
	for pair in [["真实帧间隔","frame_ms"],["已测脚本 CPU","script_ms"],["未归因间隔（非 GPU）","unattributed_interval_ms"],["主视口渲染 CPU","render_cpu_ms"],["主视口 GPU","render_gpu_ms"],["引擎帧监视器","engine_frame_ms"],["最近物理 tick","physics_tick_ms"],["采集器自身","monitor_ms"]]:
		lines.append(pair[0]+"\n"+Report.format_stats(model.metrics[pair[1]])+"\n")
	lines.append("慢帧：间隔 %d · 已测脚本 %d · 任一 %d\n超过目标预算：%d / %d 帧\n"%[model.slow_interval_frames,model.slow_script_frames,model.slow_either_frames,model.over_target_budget_frames,model.sample_frames])
	var denominator:float=maxi(1,model.sample_frames)
	lines.append("慢帧占比：间隔 %.2f%% · 脚本 %.2f%% · 任一 %.2f%%\n"%[100.0*model.slow_interval_frames/denominator,100.0*model.slow_script_frames/denominator,100.0*model.slow_either_frames/denominator])
	lines.append("诊断线索\n"+"\n".join(Report.clues(model)))
	summary.text="\n".join(lines)
	ranking.clear()
	var root_item:=ranking.create_item()
	for row in model.sections:
		var item:=ranking.create_item(root_item)
		var values:Array=[row.name,"%.3f"%row.average_ms,"%.3f"%row.p50_ms,"%.3f"%row.p95_ms,"%.3f"%row.p99_ms,"%.3f"%row.max_ms,"%.3f"%row.total_ms,"%.1f%%"%row.share_percent,"%.1f%%"%row.wall_percent,str(row.active_frames)]
		for i in values.size(): item.set_text(i,values[i]);item.set_tooltip_text(i,values[i])
	_fill_slow(slow_frames,model.slowest_interval)
	_fill_slow(slow_cpu,model.slowest_script)
	counters.text="以下是最近快照，不是窗口平均值。完整数据与口径随 JSON / Markdown 导出。\n\n"+JSON.stringify(monitor._context,"\t")

func _fill_slow(tree:Tree,frames:Array)->void:
	tree.clear()
	var root_item:=tree.create_item()
	for frame in frames:
		var item:=tree.create_item(root_item)
		var values:Array=[str(frame.sequence),"%.2f"%frame.frame_ms,"%.2f"%frame.script_ms,"%.2f"%frame.render_gpu_ms if frame.render_gpu_ms!=null else "不可用",str(frame.position),JSON.stringify(frame.sections)]
		for i in values.size(): item.set_text(i,values[i]);item.set_tooltip_text(i,values[i])

func _copy_report()->void:
	monitor.stop()
	if monitor.total_frames==0: status.text="还没有采样数据";return
	DisplayServer.clipboard_set(Report.markdown(monitor.make_report()))
	status.text="报告已复制；采样已停止"
func _export()->void:
	var result:Dictionary=monitor.export_files()
	status.text=result.get("error","已导出："+String(result.get("json","")))
func _open_directory()->void:
	var path:=ProjectSettings.globalize_path(monitor.DIRECTORY)
	if DirAccess.dir_exists_absolute(path): OS.shell_open(path)
	else: status.text="首次导出后会创建目录"
