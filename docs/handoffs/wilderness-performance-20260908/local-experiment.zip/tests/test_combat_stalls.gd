extends SceneTree
var study
func _initialize() -> void: call_deferred("run")
func run() -> void:
	study = load("res://scenes/wilderness_combat_study.tscn").instantiate()
	root.add_child(study)
	current_scene = study
	while not study.prepared: await process_frame
	while not is_instance_valid(study.director): await process_frame
	root.size = Vector2i(2560,1440)
	Engine.max_fps = 0
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
	study.player.position = study.grounded(Vector3(-5,0,25))
	study.player.rotation = Vector3.ZERO
	study.player.set_process_unhandled_input(false)
	study.player.get_node("Camera3D/CameraFx").set_process(false)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	var environment = study.world.get_node("WorldEnvironment")
	environment.weather.set_weather("rain", true)
	environment.weather._process(0.016)
	environment.apply_state(environment.sample(0.47584))
	environment.weather.set_process(false)
	environment.set_process(false)
	await create_timer(18).timeout
	var diagnostics = root.get_node("PerformanceDiagnostics")
	diagnostics.duration_seconds = 0
	diagnostics.note = "周边持续刷怪+60秒实弹；含正常换弹补弹，不含截图。details_ms 为嵌套耗时，不与 sections 相加。"
	diagnostics.start()
	var deadline := Time.get_ticks_msec() + 60000
	var next_shot := 0
	while Time.get_ticks_msec() < deadline:
		await RenderingServer.frame_post_draw
		if Time.get_ticks_msec() < next_shot: continue
		next_shot = Time.get_ticks_msec() + 180
		var victim: Node3D
		var distance := INF
		for actor in study.actors.get_children():
			if actor is CharacterBody3D and actor.get("_dead") == false:
				var d: float = actor.global_position.distance_squared_to(study.player.global_position)
				if d < distance:
					distance = d
					victim = actor
		if victim != null:
			study.player.get_node("Camera3D").look_at(victim.global_position + Vector3.UP * 0.95)
			if study.gun.ammo > 0: study.gun._shoot()
	print("STALL_REPORT ", diagnostics.export_files())
	print("STALL_RESULT ",JSON.stringify({"shots":study.shots,"kills":study.kills,"spawned":study.director.spawned,"hits":study.hits}))
	root.get_texture().get_image().save_png("res://tools/stall-study-20260908/preview.png")
	quit()
