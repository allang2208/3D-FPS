extends SceneTree
func _initialize() -> void: call_deferred("run")
func run() -> void:
	var hud = root.get_node("HUD")
	hud._ensure_built()
	var view = hud.backpack_hud
	var timings := {}
	for method in ["_refresh_hotbar", "_refresh_grid", "_refresh_equip", "_refresh"]:
		var started := Time.get_ticks_usec()
		for i in 30: view.call(method)
		timings[method] = (Time.get_ticks_usec() - started) / 30000.0
	print("RELOAD_UI_COST ", JSON.stringify(timings))
	quit()

