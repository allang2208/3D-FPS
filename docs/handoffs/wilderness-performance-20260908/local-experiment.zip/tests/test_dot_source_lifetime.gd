extends SceneTree
class Host extends Node3D:
	var hp := 1000
	var hits := 0
	var last_source: Node3D
	func take_damage(damage: int, _type := "physical", source: Node3D = null) -> void:
		hp -= damage
		hits += 1
		last_source = source
func _initialize() -> void: call_deferred("run")
func run() -> void:
	var passed := true
	for kind in ["poison", "bleed", "burn"]:
		var host := Host.new()
		var caster := Node3D.new()
		root.add_child(host)
		root.add_child(caster)
		var buffs := BuffSystem.new()
		var entry := {"stacks":3,"opts":{"source":caster,"burn_stacks":[{"remaining_s":3.0,"matk":10}],"bleed_stacks":[{"remaining_s":3.0}],"_last_dt":0.1}}
		buffs._tick_dot(kind, entry, host)
		passed = passed and host.hits == 1 and host.last_source == caster
		caster.free()
		var before := host.hp
		buffs._tick_dot(kind, entry, host)
		passed = passed and host.hits == 2 and host.hp < before
		passed = passed and (host.last_source == host if kind == "burn" else host.last_source == null)
		host.free()
	print("DOT_SOURCE_LIFETIME ", "PASS" if passed else "FAIL")
	quit(0 if passed else 1)
