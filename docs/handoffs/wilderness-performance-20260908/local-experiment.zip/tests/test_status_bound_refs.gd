extends SceneTree
class TestGun extends Node3D:
	var aim := Vector2(123, 456)
	func aim_screen_position() -> Vector2: return aim
	func hipfire_radius_pixels() -> float: return 12.0
class TestPlayer extends Node3D:
	var reads := 0
	func buff_snapshot() -> Array:
		reads += 1
		return []
func _initialize() -> void: call_deferred("run")
func run() -> void:
	var hud = root.get_node("HUD")
	if not hud._built: hud._ensure_built()
	var bar = hud.get_node("StatusBar")
	var player := TestPlayer.new()
	var gun := TestGun.new()
	root.add_child(player)
	root.add_child(gun)
	hud._bound_player = player
	hud._bound_gun = gun
	bar._profiled_process(1.0 / 60.0)
	var passed: bool = bar._aim_root.position == gun.aim and player.reads == 1
	var replacement := TestGun.new()
	replacement.aim = Vector2(789, 321)
	root.add_child(replacement)
	hud._bound_gun = replacement
	bar._profiled_process(1.0 / 60.0)
	passed = passed and bar._aim_root.position == replacement.aim and player.reads == 2
	hud._bound_gun = null
	hud._bound_player = null
	bar._profiled_process(1.0 / 60.0)
	passed = passed and bar._aim_root.position == root.get_visible_rect().size * 0.5
	print("STATUS_BOUND_REFS ", "PASS" if passed else "FAIL")
	quit(0 if passed else 1)
