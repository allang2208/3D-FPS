extends SceneTree
const OUT = "res://tools/combat-study-20260908/"
var study
var rows: Array = []

func _initialize() -> void:
	call_deferred("run")

func measure(tag: String, seconds := 12.0, shooting := false) -> void:
	var camera: Camera3D = root.get_camera_3d()
	var pose := camera.global_transform
	var intervals: Array[float] = []
	var gpu := 0.0
	var physics := 0.0
	var draws := 0.0
	var primitives := 0.0
	var started := Time.get_ticks_usec()
	var previous := started
	var hits_before: int = study.hits
	var next_shot := 0
	while Time.get_ticks_usec() - started < seconds * 1000000.0:
		await RenderingServer.frame_post_draw
		if not shooting and not camera.global_transform.is_equal_approx(pose):
			push_error("COMBAT camera changed")
			quit(1)
			return
		var now := Time.get_ticks_usec()
		if shooting and now >= next_shot:
			next_shot = now + 180000
			for actor in study.actors.get_children():
				if actor.get("_dead") == false:
					camera.look_at(actor.global_position + Vector3.UP * 0.95)
					if study.gun.ammo <= 0:
						study.gun._start_reload()
					else:
						study.gun._shoot()
					break
		intervals.append((now - previous) / 1000.0)
		previous = now
		gpu += RenderingServer.viewport_get_measured_render_time_gpu(root.get_viewport_rid())
		physics += Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS) * 1000.0
		draws += Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)
		primitives += Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME)
	var n := intervals.size()
	intervals.sort()
	var states := {}
	var actor_count := 0
	var projectile_count := 0
	for actor in study.actors.get_children():
		if not actor is CharacterBody3D:
			projectile_count += 1
			continue
		actor_count += 1
		var state := str(actor.get("state"))
		states[state] = int(states.get(state, 0)) + 1
	var row := {"case":tag,"frames":n,"seconds":(previous-started)/1000000.0,"fps":n*1000000.0/(previous-started),"gpu_ms":gpu/n,"physics_ms":physics/n,"p95_ms":intervals[int(n*0.95)],"draws":draws/n,"primitives":primitives/n,"damage_events":study.hits-hits_before,"actual_actors":study.actors.get_child_count(),"states":states,"player":str(study.player.position),"camera":str(pose)}
	rows.append(row)
	row["actual_actors"] = actor_count
	row["other_children"] = projectile_count
	row["shots"] = study.shots
	row["kills"] = study.kills
	print("COMBAT_ROW ", JSON.stringify(row))
	root.get_texture().get_image().save_png(OUT + tag + ".png")
	var file := FileAccess.open(OUT + "benchmark.json", FileAccess.WRITE)
	file.store_string(JSON.stringify(rows, "\t"))

func run() -> void:
	study = load("res://scenes/wilderness_combat_study.gd").new()
	study.automated = true
	root.add_child(study)
	current_scene = study
	await create_timer(8.0).timeout
	while not study.prepared:
		await process_frame
	root.size = Vector2i(2560,1440)
	Engine.max_fps = 0
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
	# Keep the actual player physics and BuffSystem running, including poison DoT.
	study.player.rotation = Vector3.ZERO
	study.player.set_process_unhandled_input(false)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	var camera: Camera3D = root.get_camera_3d()
	camera.rotation = Vector3(-0.12, 0, 0)
	camera.fov = 75
	study.player.get_node("Camera3D/CameraFx").set_process(false)
	var environment = study.world.get_node("WorldEnvironment")
	environment.weather.set_weather("rain", true)
	environment.weather._process(0.016)
	environment.apply_state(environment.sample(0.47584))
	environment.weather.set_process(false)
	environment.set_process(false)
	RenderingServer.viewport_set_measure_render_time(root.get_viewport_rid(),true)
	var diagnostics = root.get_node("PerformanceDiagnostics")
	diagnostics.duration_seconds = 0
	diagnostics.start()
	print("COMBAT_CONFIG ",JSON.stringify({"resolution":str(root.size),"msaa":root.msaa_3d,"gpu":RenderingServer.get_video_adapter_name(),"sun_shadows":study.world.get_node("Sun").shadow_enabled,"rain":true,"physics_hz":Engine.physics_ticks_per_second}))
	var focused := OS.get_environment("COMBAT_FOCUSED") == "1"
	for count in ([30] if focused else [0,10,30,60]):
		await study.populate(count)
		await create_timer(3.0).timeout
		await measure("actors_%d" % count)
	if focused:
		await study.populate(30)
		await measure("live_fire", 20.0, true)
		print("COMBAT_REPORT ", diagnostics.export_files())
		print("COMBAT_TEST COMPLETE")
		quit()
		return
	await study.populate(30)
	await create_timer(5.0).timeout
	await measure("thirty_visible_A")
	study.actors.visible = false
	await measure("thirty_hidden")
	study.actors.visible = true
	await measure("thirty_visible_B")
	study.world.get_node("ParticleGrass").visible = false
	await measure("thirty_grass_hidden")
	study.world.get_node("ParticleGrass").visible = true
	await measure("thirty_grass_restored")
	await study.populate(2,true)
	await create_timer(3.0).timeout
	await measure("bosses_and_summons", 20.0)
	await study.populate(30)
	await measure("live_fire", 20.0, true)
	print("COMBAT_REPORT ", diagnostics.export_files())
	print("COMBAT_TEST COMPLETE")
	quit()
