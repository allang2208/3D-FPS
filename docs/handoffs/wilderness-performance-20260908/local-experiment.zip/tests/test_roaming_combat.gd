extends SceneTree
var study
var failed := false
func _initialize() -> void: call_deferred("run")
func check(ok: bool, message: String) -> void:
	print("ROAMING ", message, " ", "PASS" if ok else "FAIL")
	failed = failed or not ok
func wait_spawn(total: int) -> void:
	var deadline := Time.get_ticks_msec() + 18000
	while study.director.spawned < total and Time.get_ticks_msec() < deadline:
		await process_frame
func run() -> void:
	study = load("res://scenes/wilderness_combat_study.tscn").instantiate()
	root.add_child(study)
	current_scene = study
	while not study.prepared: await process_frame
	while not is_instance_valid(study.director): await process_frame
	study.player.set_process_unhandled_input(false)
	study.director.target_count = 4
	await wait_spawn(4)
	check(study.director.spawned >= 4, "initial_spawn")
	await create_timer(2).timeout
	check(study.director.alive == 4, "population_cap")
	var victim = null
	for actor in study.actors.get_children():
		if actor is CharacterBody3D and actor.get("_dead") == false:
			victim = actor
			break
	if victim != null: victim.take_damage(999999)
	var next: int = study.director.spawned + 1
	await wait_spawn(next)
	check(study.director.spawned >= next and study.kills == 1, "death_replenished")
	var before: int = study.director.retired
	study.player.position = study.grounded(Vector3(140, 0, 30))
	study.player.velocity = Vector3.ZERO
	await create_timer(2).timeout
	check(study.director.retired >= before + 3, "old_area_recycled")
	next = study.director.spawned + 1
	await wait_spawn(next)
	check(study.director.spawned >= next, "new_area_spawned")
	print("ROAMING_TEST COMPLETE failures=", 1 if failed else 0)
	quit(1 if failed else 0)
