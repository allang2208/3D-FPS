extends RefCounted
## Statistical contract migrated from game-dev PerformanceMonitor.
static func stats(values:Array)->Dictionary:
	if values.is_empty(): return {"available":false,"count":0}
	var sorted:=values.duplicate()
	sorted.sort()
	var total:=0.0
	for value in values: total+=value
	return {"available":true,"count":values.size(),"total_ms":total,"average_ms":total/values.size(),"p50_ms":sorted[int((sorted.size()-1)*0.5)],"p95_ms":sorted[int((sorted.size()-1)*0.95)],"p99_ms":sorted[int((sorted.size()-1)*0.99)],"max_ms":sorted[-1]}

static func summarize(frames:Array,threshold:float=33.34,target_fps:float=140)->Dictionary:
	var metrics:Dictionary={}
	for key in ["frame_ms","script_ms","unattributed_interval_ms","render_cpu_ms","render_gpu_ms","engine_frame_ms","physics_tick_ms","monitor_ms"]:
		var values:Array=[]
		for frame in frames:
			if frame.get(key)!=null: values.append(frame[key])
		metrics[key]=stats(values)
	var names:Dictionary={}
	for frame in frames:
		for key in frame.sections: names[key]=true
	var sections:Array=[]
	var section_total:=0.0
	for key in names:
		var values:Array=[]
		var active:=0
		for frame in frames:
			var value:float=frame.sections.get(key,0.0)
			values.append(value)
			if value>0: active+=1
		var row:=stats(values)
		row["name"]=key
		row["active_frames"]=active
		section_total+=row.total_ms
		sections.append(row)
	var duration:float=metrics.frame_ms.get("total_ms",0.0)
	for row in sections:
		row["share_percent"]=100.0*row.total_ms/maxf(section_total,0.0001)
		row["wall_percent"]=100.0*row.total_ms/maxf(duration,0.0001)
	sections.sort_custom(func(a:Dictionary,b:Dictionary)->bool: return a.average_ms>b.average_ms)
	var interval_slow:=0
	var cpu_slow:=0
	var either_slow:=0
	var budget_missed:=0
	for frame in frames:
		if frame.frame_ms>=threshold: interval_slow+=1
		if frame.script_ms>=threshold: cpu_slow+=1
		if maxf(frame.frame_ms,frame.script_ms)>=threshold: either_slow+=1
		if frame.frame_ms>1000.0/target_fps: budget_missed+=1
	var slowest:=frames.duplicate()
	slowest.sort_custom(func(a:Dictionary,b:Dictionary)->bool:return a.frame_ms>b.frame_ms)
	var slow_cpu:=frames.duplicate()
	slow_cpu.sort_custom(func(a:Dictionary,b:Dictionary)->bool:return a.script_ms>b.script_ms)
	return {"sample_frames":frames.size(),"duration_ms":duration,"average_fps":1000.0*frames.size()/duration if duration>0 else 0.0,"metrics":metrics,"sections":sections,"slow_threshold_ms":threshold,"slow_interval_frames":interval_slow,"slow_script_frames":cpu_slow,"slow_either_frames":either_slow,"target_fps":target_fps,"over_target_budget_frames":budget_missed,"slowest_interval":slowest.slice(0,8),"slowest_script":slow_cpu.slice(0,8)}

static func clues(model:Dictionary)->Array[String]:
	var result:Array[String]=[]
	if model.sample_frames<30:
		result.append("样本不足 30 帧，请继续采样。")
		return result
	var metrics:Dictionary=model.metrics
	if model.sections.size()>0:
		var top:Dictionary=model.sections[0]
		result.append("最重已测分项：%s，平均 %.2f ms，P95 %.2f ms。"%[top.name,top.average_ms,top.p95_ms])
	if metrics.render_gpu_ms.available:
		if metrics.render_gpu_ms.average_ms>1000.0/model.target_fps:
			result.append("主视口 GPU 渲染时间超过目标帧预算，可优先做渲染选项 A/B。")
	else: result.append("GPU 时间暂不可用；不会用帧间隔差值冒充 GPU 时间。")
	if model.slow_interval_frames>model.slow_script_frames:
		result.append("帧间隔慢帧多于已测脚本慢帧：还需检查渲染、等待与未埋点代码。")
	if metrics.frame_ms.p99_ms>metrics.frame_ms.average_ms*2.5:
		result.append("存在尾部尖峰，结合慢帧的位置、计数器与分项判断触发条件。")
	result.append("以上是诊断线索，不是完整 CPU/GPU profiler 结论。")
	return result

static func format_stats(metric:Dictionary)->String:
	if not metric.get("available",false): return "不可用"
	return "平均 %.3f / P50 %.3f / P95 %.3f / P99 %.3f / 峰值 %.3f ms"%[metric.average_ms,metric.p50_ms,metric.p95_ms,metric.p99_ms,metric.max_ms]

static func markdown(report:Dictionary)->String:
	var model:Dictionary=report.window
	var lines:Array[String]=["# 无尽轮回 Godot 性能报告","","- 导出时间："+report.exported_at,"- 备注："+String(report.get("note","")),"- 窗口 %d 帧，实际 %.2f 秒，平均 %.1f FPS"%[model.sample_frames,model.duration_ms/1000.0,model.average_fps],"- 累计采样 %d 帧，保留 %d 帧，覆盖丢弃 %d 帧"%[report.total_frames,report.retained_frames,report.overwritten_frames],"- 面板可见帧数：%d；暂停帧数：%d"%[report.panel_visible_frames,report.paused_frames],""]
	for key in model.metrics: lines.append("- %s：%s"%[key,format_stats(model.metrics[key])])
	lines.append("- 慢帧：间隔 %d / 脚本 %d / 任一 %d；阈值 %.2f ms；超过目标 %.0f FPS 预算 %d 帧"%[model.slow_interval_frames,model.slow_script_frames,model.slow_either_frames,model.slow_threshold_ms,model.target_fps,model.over_target_budget_frames])
	var denominator:float=maxi(1,model.sample_frames)
	lines.append("- 慢帧占比：间隔 %.2f%% / 脚本 %.2f%% / 任一 %.2f%%"%[100.0*model.slow_interval_frames/denominator,100.0*model.slow_script_frames/denominator,100.0*model.slow_either_frames/denominator])
	lines.append("\n## 全部保留帧概览\n\n- %d 帧 / %.2f 秒 / 平均 %.1f FPS"%[report.session.sample_frames,report.session.duration_ms/1000.0,report.session.average_fps])
	for key in report.session.metrics: lines.append("- %s：%s"%[key,format_stats(report.session.metrics[key])])
	lines.append("\n## 诊断线索\n")
	for clue in clues(model): lines.append("- "+clue)
	lines.append("\n## 已测 CPU 分项\n\n| 分项 | 平均 ms | P50 | P95 | P99 | 峰值 | 累计 ms | 分项占比 | 墙钟占比 | 活跃帧 |\n|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|")
	for row in model.sections:
		lines.append("| %s | %.3f | %.3f | %.3f | %.3f | %.3f | %.3f | %.1f%% | %.1f%% | %d |"%[row.name,row.average_ms,row.p50_ms,row.p95_ms,row.p99_ms,row.max_ms,row.total_ms,row.share_percent,row.wall_percent,row.active_frames])
	for kind in ["slowest_interval","slowest_script"]:
		lines.append("\n## %s\n\n| 帧序 | 帧间隔 ms | 脚本 ms | 未归因间隔 ms | 位置 | 分项 |\n|---:|---:|---:|---:|---|---|"%kind)
		for frame in model[kind]: lines.append("| %d | %.3f | %.3f | %.3f | %s | %s |"%[frame.sequence,frame.frame_ms,frame.script_ms,frame.unattributed_interval_ms,str(frame.position),JSON.stringify(frame.sections)])
	lines.append("\n## 导出快照（非窗口平均）\n\n```json\n"+JSON.stringify(report.context,"\t")+"\n```")
	lines.append("\n## 口径\n")
	for note in report.caveats: lines.append("- "+note)
	return "\n".join(lines)
