extends Node
## Always available in game; expensive sampling is opt-in and bounded.
const Probe=preload("res://scripts/performance_probe.gd")
const Report=preload("res://scripts/performance_report.gd")
const CAPACITY:=18000
const DIRECTORY:="user://performance_reports"
var recording:=false
var window_frames:=240
var threshold_ms:=33.34
var target_fps:=140.0
var duration_seconds:=30.0
var note:=""
var total_frames:=0
var _history:Array=[]
var _next:=0
var _sections:Dictionary={}
var _details:Dictionary={}
var _last_tick:=0
var _start_tick:=0
var _context_tick:=0
var _context:Dictionary={}
var _context_id:=0
var _contexts:Array=[]
var _panel:CanvasLayer
var _monitor_ms:=0.0
var _session_id:=0
var last_export:=""

func _ready()->void:
	process_mode=Node.PROCESS_MODE_ALWAYS
	Probe.sink=self
	_history.resize(CAPACITY)
	RenderingServer.frame_post_draw.connect(_sample_frame)
	get_tree().scene_changed.connect(_scene_changed)

func _exit_tree()->void:
	Probe.sink=null
	RenderingServer.viewport_set_measure_render_time(get_viewport().get_viewport_rid(),false)

func _scene_changed()->void:
	_context_tick=0
	if is_instance_valid(_panel): _panel.close_panel()

func _input(event:InputEvent)->void:
	if event is InputEventKey and event.pressed and not event.echo and event.keycode==KEY_F10:
		show_panel()
		get_viewport().set_input_as_handled()

func show_panel()->void:
	if not is_instance_valid(_panel):
		_panel=preload("res://ui/performance_panel.gd").new()
		_panel.monitor=self
		add_child(_panel)
	if _panel.is_open(): _panel.close_panel()
	else: _panel.open_panel()

func panel_visible()->bool:
	return is_instance_valid(_panel) and _panel.is_open()

func reset()->void:
	total_frames=0
	_next=0
	_history.fill(null)
	_sections.clear()
	_details.clear()
	_contexts.clear()
	_context_id=0
	_last_tick=0
	_start_tick=Time.get_ticks_usec()
	_context_tick=0
	_session_id+=1

func start()->void:
	reset()
	recording=true
	RenderingServer.viewport_set_measure_render_time(get_viewport().get_viewport_rid(),true)
	_collect_context()

func stop()->void:
	recording=false
	_sections.clear()
	_details.clear()
	RenderingServer.viewport_set_measure_render_time(get_viewport().get_viewport_rid(),false)

func add_detail(section:StringName,ms:float)->void:
	_details[section]=float(_details.get(section,0.0))+ms

func add_section(section:StringName,ms:float)->void:
	_sections[section]=float(_sections.get(section,0.0))+ms

func _process(_delta:float)->void:
	if not recording: return
	var now:=Time.get_ticks_usec()
	if duration_seconds>0 and now-_start_tick>=duration_seconds*1000000.0:
		stop()
		return
	if now-_context_tick>500000:
		var begin:=Time.get_ticks_usec()
		_collect_context()
		_monitor_ms+=(Time.get_ticks_usec()-begin)/1000.0

func _sample_frame()->void:
	if not recording: return
	var begin:=Time.get_ticks_usec()
	if _last_tick==0:
		_last_tick=begin
		_sections.clear()
		_details.clear()
		return
	var frame_ms:float=(begin-_last_tick)/1000.0
	_last_tick=begin
	var script_ms:=0.0
	for ms in _sections.values(): script_ms+=ms
	var rid:=get_viewport().get_viewport_rid()
	var gpu:=RenderingServer.viewport_get_measured_render_time_gpu(rid)
	var render_cpu:=RenderingServer.viewport_get_measured_render_time_cpu(rid)
	var player:Node=get_tree().get_first_node_in_group("player")
	if player==null and get_tree().current_scene!=null: player=get_tree().current_scene.get_node_or_null("Player")
	var position:Array=[]
	if player is Node3D: position=[player.global_position.x,player.global_position.y,player.global_position.z]
	var cpu_sample: Variant = null
	var gpu_sample: Variant = null
	if render_cpu>0: cpu_sample=render_cpu
	if gpu>0: gpu_sample=gpu
	total_frames+=1
	var pipelines := {
		"canvas": Performance.get_monitor(Performance.PIPELINE_COMPILATIONS_CANVAS),
		"mesh": Performance.get_monitor(Performance.PIPELINE_COMPILATIONS_MESH),
		"surface": Performance.get_monitor(Performance.PIPELINE_COMPILATIONS_SURFACE),
		"draw": Performance.get_monitor(Performance.PIPELINE_COMPILATIONS_DRAW),
		"specialization": Performance.get_monitor(Performance.PIPELINE_COMPILATIONS_SPECIALIZATION)}
	_history[_next]={"pipeline_compilations":pipelines,"sequence":total_frames,"elapsed_ms":(begin-_start_tick)/1000.0,"frame_ms":frame_ms,"script_ms":script_ms,"unattributed_interval_ms":maxf(0,frame_ms-script_ms),"render_cpu_ms":cpu_sample,"render_gpu_ms":gpu_sample,"engine_frame_ms":Performance.get_monitor(Performance.TIME_PROCESS)*1000.0,"physics_tick_ms":Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS)*1000.0,"sections":_sections,"details_ms":_details,"position":position,"context_id":_context_id,"panel_visible":panel_visible(),"paused":get_tree().paused,"draw_calls":Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME),"triangles":Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME),"monitor_ms":_monitor_ms}
	_next=(_next+1)%CAPACITY
	_sections={}
	_details={}
	_monitor_ms=(Time.get_ticks_usec()-begin)/1000.0

func _collect_context()->void:
	_context_tick=Time.get_ticks_usec()
	var scene:=get_tree().current_scene
	_context_id+=1
	_context={"id":_context_id,"at_ms":(_context_tick-_start_tick)/1000.0,"scene":scene.scene_file_path if scene!=null else "","device_reported_name":RenderingServer.get_video_adapter_name(),"driver":RenderingServer.get_current_rendering_driver_name(),"renderer":RenderingServer.get_current_rendering_method(),"engine":Engine.get_version_info(),"os":OS.get_name(),"cpu":OS.get_processor_name(),"resolution":str(get_viewport().get_visible_rect().size),"render_scale":get_viewport().scaling_3d_scale,"msaa_3d":get_viewport().msaa_3d,"max_fps":Engine.max_fps,"vsync":DisplayServer.window_get_vsync_mode(),"panel_visible":panel_visible(),"paused":get_tree().paused,"objects":Performance.get_monitor(Performance.OBJECT_COUNT),"nodes":Performance.get_monitor(Performance.OBJECT_NODE_COUNT),"resources":Performance.get_monitor(Performance.OBJECT_RESOURCE_COUNT),"orphans":Performance.get_monitor(Performance.OBJECT_ORPHAN_NODE_COUNT),"static_memory_bytes":OS.get_static_memory_usage(),"render_memory_bytes":Performance.get_monitor(Performance.RENDER_VIDEO_MEM_USED),"physics_active":Performance.get_monitor(Performance.PHYSICS_3D_ACTIVE_OBJECTS),"physics_pairs":Performance.get_monitor(Performance.PHYSICS_3D_COLLISION_PAIRS)}
	if scene!=null:
		var director = scene.get("director")
		if is_instance_valid(director):
			_context["encounter"]={"alive":director.alive,"target":director.target_count,"spawned":director.spawned,"retired":director.retired,"enabled":director.enabled}
		# Combat laboratories wrap the real world as a child scene.
		var world_scene: Node = scene
		if scene.get("world") is Node3D:
			world_scene = scene.get("world")
		var far:=world_scene.get_node_or_null("WildernessFarField")
		if far!=null:
			_context["world_seed"]=far.world_seed
			_context["landform_revision"]=far.landform_revision
			var presenter:Node=far._presenter
			if is_instance_valid(presenter):
				_context["stream"]={"loaded":presenter._loaded.size(),"pending":presenter._pending.size(),"stage":presenter._build_job.get("stage",-1),"peak_stage_ms":presenter.peak_stage_ms.duplicate(),"dirty_surfaces":presenter._dirty_surfaces.size()}
				if is_instance_valid(presenter.harvestables): _context.stream["harvest_entries"]=presenter.harvestables.entries.size()
				var grass:=presenter.get_node_or_null("StreamedMeadow")
				if grass!=null: _context.stream["grass_cells"]=grass.cells.size()
			if is_instance_valid(far._scheduler):
				_context["cache"]={"queued":far._scheduler.queue_size(),"completed":far._scheduler.completed_chunks,"failed":far._scheduler.failed_chunks}
		var editor:=world_scene.get_node_or_null("WildernessEditor")
		if editor!=null: _context["terrain_edits"]={"columns":editor.world.columns.size(),"jobs":editor.world.jobs.size()}
		var sun:=world_scene.get_node_or_null("Sun")
		if sun!=null: _context["sun"]={"shadows":sun.shadow_enabled,"shadow_distance":sun.directional_shadow_max_distance}
		var env:=world_scene.get_node_or_null("WorldEnvironment")
		if env!=null and env.get("current_state")!=null: _context["day_night"]=env.current_state.duplicate()
	_contexts.append(_context)
	# At most one context refresh per processed frame; keep enough history to
	# resolve context_id even during a very low-FPS manual recording.
	if _contexts.size()>CAPACITY+1: _contexts.pop_front()

func frames(limit:int=CAPACITY)->Array:
	var count:=mini(mini(total_frames,CAPACITY),limit)
	var result:Array=[]
	for i in count: result.append(_history[posmod(_next-count+i,CAPACITY)])
	return result

func snapshot()->Dictionary:
	return Report.summarize(frames(window_frames),threshold_ms,target_fps)

func make_report()->Dictionary:
	var retained:=frames()
	var panel_frames:=0
	var paused_frames:=0
	for frame in retained:
		if frame.panel_visible: panel_frames+=1
		if frame.paused: paused_frames+=1
	return {"schema_version":1,"exported_at":Time.get_datetime_string_from_system(),"note":note,"total_frames":total_frames,"retained_frames":retained.size(),"overwritten_frames":maxi(0,total_frames-CAPACITY),"panel_visible_frames":panel_frames,"paused_frames":paused_frames,"window":snapshot(),"session":Report.summarize(retained,threshold_ms,target_fps),"context":_context,"context_timeline":_contexts.duplicate(),"frames":retained,"caveats":["frame_ms 是未截断的真实绘制间隔；包括等待、渲染和未埋点工作。","script_ms 是已埋点独立回调之和，不是总 CPU 占用。分项占比仅针对这些埋点。","unattributed_interval_ms 是间隔减已测脚本的剩余值，不是 GPU 耗时。","渲染 CPU/GPU 仅测主视口，读数可能异步滞后；不与脚本/物理简单相加。不可用值为 null。","engine_frame_ms 是引擎主循环监视器，不是纯脚本时间；physics_tick_ms 是最近物理 tick，而非当帧全部物理累计。","context 为最后采样快照，不是窗口平均。计数器时间线通过 context_id 关联。","渲染内存统计不是物理显存驻留量；设备名称取引擎报告，可能与系统硬件名称不一致。","打开面板会影响渲染与角色输入；建议关闭面板录制，在停止后查看与导出。","监测开销随埋点数量而变，monitor_ms 只含采集器工作，未包含所有包装调用和面板绘制。"]}

func export_files()->Dictionary:
	stop()
	var report:=make_report()
	if report.retained_frames==0: return {"error":"还没有采样数据"}
	var error:=DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(DIRECTORY))
	if error!=OK: return {"error":"无法创建导出目录："+error_string(error)}
	var stamp:=Time.get_datetime_string_from_system().replace(":","-")
	var base:=DIRECTORY.path_join("performance-%s-%d-%d"%[stamp,OS.get_process_id(),Time.get_ticks_msec()])
	for extension in ["json","md"]:
		var file:=FileAccess.open(base+"."+extension,FileAccess.WRITE)
		if file==null: return {"error":"写入失败："+error_string(FileAccess.get_open_error())}
		file.store_string(JSON.stringify(report,"\t") if extension=="json" else Report.markdown(report))
	last_export=ProjectSettings.globalize_path(base+".json")
	return {"json":last_export,"markdown":ProjectSettings.globalize_path(base+".md")}
