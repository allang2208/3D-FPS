extends RefCounted
## Lightweight, opt-in timing for independent engine callbacks.
static var sink:Node
static func begin()->int:
	return Time.get_ticks_usec() if is_instance_valid(sink) and sink.recording else 0
static func end(section:StringName,started:int)->void:
	if started>0 and is_instance_valid(sink) and sink.recording:
		sink.add_section(section,(Time.get_ticks_usec()-started)/1000.0)

## Nested timings are diagnostic detail, never added to script_ms again.
static func detail(section:StringName,started:int)->void:
	if started>0 and is_instance_valid(sink) and sink.recording:
		sink.add_detail(section,(Time.get_ticks_usec()-started)/1000.0)
