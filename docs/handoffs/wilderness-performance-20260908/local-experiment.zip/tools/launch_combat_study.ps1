param([switch]$Benchmark)
$ErrorActionPreference = 'Stop'
$env:INVENTORY_SAVE_PATH = 'user://combat-study-inventory.save'
$env:GAME_SETTINGS_PATH = 'user://combat-study-settings.json'
$combatEngine = 'E:/3d/Godot_v4.7.1-stable_win64.exe/Godot_v4.7.1-stable_win64_console.exe'
$combatArguments = '--path E:/3d/3-dfps res://scenes/wilderness_combat_study.tscn'
if ($Benchmark) { $combatArguments = '--path E:/3d/3-dfps --script res://tests/test_wilderness_combat.gd' }
Start-Process -FilePath $combatEngine -ArgumentList $combatArguments -WindowStyle Hidden
