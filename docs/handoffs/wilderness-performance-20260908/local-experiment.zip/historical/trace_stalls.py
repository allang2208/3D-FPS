from pathlib import Path
r=Path('E:/3d/3-dfps')
def edit(path,fn):
 p=r/path;s=p.read_text(encoding='utf-8');p.write_text(fn(s),encoding='utf-8')
edit('scripts/performance_probe.gd',lambda s:s+'''\n## Nested timings are diagnostic detail, never added to script_ms again.
static func detail(section:StringName,started:int)->void:
 if started>0 and is_instance_valid(sink) and sink.recording:
  sink.add_detail(section,(Time.get_ticks_usec()-started)/1000.0)
''')
def diag(s):
 s=s.replace('var _sections:Dictionary={}','var _sections:Dictionary={}\nvar _details:Dictionary={}',1)
 s=s.replace('\t_sections.clear()','\t_sections.clear()\n'+ '\t_details.clear()')
 # First-sample reset is indented inside a branch.
 s=s.replace('\t\t_sections.clear()\n\t_details.clear()','\t\t_sections.clear()\n\t\t_details.clear()')
 s=s.replace('func add_section(', 'func add_detail(section:StringName,ms:float)->void:\n\t_details[section]=float(_details.get(section,0.0))+ms\n\nfunc add_section(',1)
 s=s.replace('"sections":_sections,','"sections":_sections,"details_ms":_details,',1)
 s=s.replace('\t_sections={}\n','\t_sections={}\n\t_details={}\n',1)
 needle='\tif scene!=null:\n'
 extra='''\tif scene!=null:
\t\tvar director = scene.get("director")
\t\tif is_instance_valid(director):
\t\t\t_context["encounter"]={"alive":director.alive,"target":director.target_count,"spawned":director.spawned,"retired":director.retired,"enabled":director.enabled}
'''
 assert needle in s;s=s.replace(needle,extra,1)
 return s
edit('scripts/performance_diagnostics.gd',diag)
def wrap(s,name,args,label,ind='\t',static=False):
 prefix='static ' if static else ''
 signature=f'{prefix}func {name}({args})'
 start=s.index(signature);end=s.index('\n',start)
 line=s[start:end]
 call='delta' if name=='_physics_process' else 'data, path' if name=='write_snapshot' else ''
 result='var result := ' if name=='write_snapshot' else ''
 return_stmt=f'{ind}return result\n' if result else ''
 wrapper=line+f'\n{ind}var traced := preload("res://scripts/performance_probe.gd").begin()\n{ind}{result}_traced{name}({call})\n{ind}preload("res://scripts/performance_probe.gd").'+('end' if name=='_physics_process' else 'detail')+f'(&"{label}", traced)\n'+return_stmt+'\n'+line.replace(f'func {name}(',f'func _traced{name}(')
 return s[:start]+s[start:].replace(line,wrapper,1)
edit('scripts/roaming_combat_spawner.gd',lambda s:wrap(s,'_physics_process','delta: float','旷野/周边刷怪'))
edit('ui/inventory_save.gd',lambda s:wrap(s,'write_snapshot','data: Dictionary, path := PATH','存档/写入',static=True))
def gun(s):
 s=wrap(s,'_shoot','','武器/开火总计')
 s=wrap(s,'_finish_reload','','武器/换弹结算')
 s=s.replace('\t# Snapshot the displayed aim', '\tvar traced_part := preload("res://scripts/performance_probe.gd").begin()\n\t# Snapshot the displayed aim',1)
 s=s.replace('\t_spread_recovery_left = data.spread_recovery_delay','\tpreload("res://scripts/performance_probe.gd").detail(&"开火/瞄准与动画", traced_part)\n\t_spread_recovery_left = data.spread_recovery_delay',1)
 # Only alter the shot emission inside the traced shooting method.
 start=s.index('func _traced_shoot()')
 a,b=s[:start],s[start:]
 b=b.replace('\tshot.emit(ammo, reserve)','\ttraced_part = preload("res://scripts/performance_probe.gd").begin()\n\tshot.emit(ammo, reserve)\n\tpreload("res://scripts/performance_probe.gd").detail(&"开火/信号回调", traced_part)',1)
 b=b.replace('\t_spawn_casing()','\ttraced_part = preload("res://scripts/performance_probe.gd").begin()\n\t_spawn_casing()\n\tpreload("res://scripts/performance_probe.gd").detail(&"开火/抛壳", traced_part)',1)
 b=b.replace('\tvar target := ray_origin','\ttraced_part = preload("res://scripts/performance_probe.gd").begin()\n\tvar target := ray_origin',1)
 b=b.replace('\tproj.killed.connect(_on_proj_kill)','\tproj.killed.connect(_on_proj_kill)\n\tpreload("res://scripts/performance_probe.gd").detail(&"开火/查询与弹道", traced_part)',1)
 return a+b
edit('scripts/gun.gd',gun)
